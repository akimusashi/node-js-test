CREATE VIEW v_all AS
  SELECT
    `db_test`.`product`.`prod_id`      AS `prod_id`,
    `db_test`.`product`.`rfid_id`      AS `rfid_id`,
    `db_test`.`product`.`prod_part`    AS `prod_part`,
    `db_test`.`product`.`prod_level`   AS `prod_level`,
    `db_test`.`seller`.`sel_name`      AS `sel_name`,
    `db_test`.`seller`.`sel_address`   AS `sel_address`,
    `db_test`.`feed`.`breed`           AS `breed`,
    `db_test`.`feed`.`feed_place`      AS `feed_place`,
    `db_test`.`immune`.`imm_time`      AS `imm_time`,
    `db_test`.`immune`.`certif_id`     AS `certif_id`,
    `db_test`.`slaughter`.`slaut_date` AS `slaut_date`,
    `db_test`.`slaughter`.`slaut_time` AS `slaut_time`
  FROM ((((((`db_test`.`product`
    JOIN `db_test`.`distribute`) JOIN `db_test`.`seller`) JOIN `db_test`.`storage`) JOIN `db_test`.`feed`) JOIN
    `db_test`.`immune`) JOIN `db_test`.`slaughter`)
  WHERE (locate(`db_test`.`product`.`prod_id`, `db_test`.`distribute`.`prod_ids`) AND
         (`db_test`.`distribute`.`stg_id` = convert(`db_test`.`storage`.`stg_id` USING utf8)) AND
         (`db_test`.`storage`.`sel_id` = `db_test`.`seller`.`sel_id`) AND
         (`db_test`.`product`.`rfid_id` = `db_test`.`feed`.`rfid_id`) AND
         (`db_test`.`product`.`rfid_id` = `db_test`.`immune`.`rfid_id`) AND
         (`db_test`.`product`.`rfid_id` = `db_test`.`slaughter`.`rfid_id`));

